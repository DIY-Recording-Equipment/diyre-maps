const fs = require("fs");
const parseString = require('xml2js').parseString;



let svgFile = fs.readFileSync("OLA5 IBM Final.svg", {
    encoding: "utf8"
});

// console.log(svgFile);

parseString(svgFile, function (err, res) {

    let output = buildList(res.svg);
    let coms = {
        coms: {},
        steps:  {
            "1": "<a href='' target='_blank'>Bag 1 in Assembly Guide</a>",
            "2": "<a href='' target='_blank'>Bag 2 in Assembly Guide</a>",
            "3": "<a href='' target='_blank'>Bag 3 in Assembly Guide</a>",
            "4": "<a href='' target='_blank'>Bag 4 in Assembly Guide</a>",
            "5": "<a href='' target='_blank'>Bag 5 in Assembly Guide</a>",
            "6": "<a href='' target='_blank'>Bag 6 in Assembly Guide</a>",
            "7": "<a href='' target='_blank'>Bag 7 in Assembly Guide</a>",
            "8": "<a href='' target='_blank'>Bag 8 in Assembly Guide</a>",
            "9": "<a href='' target='_blank'>Bag 9 in Assembly Guide</a>",
            "T1": "Resistors",
            "T2": "Small Capacitors, Fuses",
            "T3": "Small Capacitors",
            "T4": "Filter Capacitors",
            "T5": "Large Capacitors",
            "T6": "Potentiometers",
            "T7": "Daughterboard Parts",
            "T8": "Integrated Circuits",
            "T9":"Vintage Output Bundle (Optional)"
        }
    };

    for (i in output) {
        for (j in output[i]) {

            if (i == 0) {

            } else if (i == 1) {
                coms.coms[output[i][j]] = {
                    "type": "PCB"
                }
            } else if (i == 2) {
                coms.coms[output[i][j]] = {
                    "type": "SIDE"
                }
            } else if (i == 3) {
                if (toString(output[i][j]).substring(0, 2) == "BG") {
                    coms.coms[output[i][j]] = {
                        "type": "BG"
                    }
                }
            } else if (i > 3 && toString(output[i][j]).substring(0, 4) != "LWPO") {
                coms.coms[output[i][j]] = {
                    "type": "COM",
                    "val": "NA",
                    "step": "NA",
                    "alt-name": output[i][j]
                }
            }

        }
    }



    fs.writeFileSync('output.json', JSON.stringify(coms, null, 2));

});

function buildList(res, ind = 0) {

    let tempOuput = {};
    tempOuput[ind] = [];
    // console.log(ind);
    for (i in res) {
        if (i == "$") {
            // console.log("has $");
            if (res.$.id != undefined) {
                tempOuput[ind].push(res.$.id);
            }

        } else if (i == "g" && res.g.length > 0) {
            //console.log("has g");

            for (j in res.g) {
                let temp;
                temp = buildList(res.g[j], ind + 1);

                for (k in temp) {
                    if (tempOuput[k] == undefined) {
                        tempOuput[k] = [];
                    }
                    for (l in temp[k]) {
                        //console.log(temp)
                        // console.log(temp[k][l])
                        // console.log("---")
                        tempOuput[k].push(temp[k][l]);
                    }
                }

            }

        }
    }

    return tempOuput;

}